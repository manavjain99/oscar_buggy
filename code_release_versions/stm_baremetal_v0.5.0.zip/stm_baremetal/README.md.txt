Release v0.1.0 
BLinky LED configs done using GUI and application done using HAL codes. 

Release v0.2.0
Added UART TX

Release v0.3.0 
UART RX Interrupt

Release v0.4.0 
ITM printf working 


Release v0.5.0 
Data parsing and storing succeess.